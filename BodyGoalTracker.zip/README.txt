Project Name: BodyGoal Tracker 🎯

Author: Humza Siddiqui

Description:
This web app calculates your healthy weight goal based on BMI 22, using your height and current weight. It provides:

Target weight in kg.

Estimated days to reach your goal.

Suggested daily calories to gain, lose, or maintain weight.

Personalized meal or activity plan using AI (Gemini API) with a friendly fitness/nutrition guide.

Features:

Responsive, modern UI with Tailwind CSS.

Gym-themed background with readable, stylish text blocks.

Interactive buttons with hover effects and loading spinner.

Data saved to Firebase Firestore anonymously for tracking.

Fast, simple, beginner-friendly, and visually appealing.

Usage:

Enter your weight and height.

Click Calculate My Goal.

Click Get Personalized Plan for AI-driven suggestions.

View your recommended action plan and goal details.

Tech Stack:

HTML + Tailwind CSS + JavaScript

Firebase Firestore for storing results

Gemini API for AI-driven suggestions

Note: API key required for AI suggestions to work.